# Data

Place verified historical match results here as `matches.csv`.

Required columns:
`date,league,home_team,away_team,reg_home_goals,reg_away_goals`

The goal columns must represent the score after 60 minutes only. Do not enter overtime or shootout goals as regulation goals. Keep source and collection timestamp documentation alongside any imported dataset.
